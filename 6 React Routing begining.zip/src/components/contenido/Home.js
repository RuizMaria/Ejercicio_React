
function Home() {
    return (
        <>
            <h2>BIENVENIDOS A NUESTRO PORTAL</h2>
            <p>Esta es nuestra idea.</p>
        </>
    )
}

export default Home;