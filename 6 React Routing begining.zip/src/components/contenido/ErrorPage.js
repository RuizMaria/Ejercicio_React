
function ErrorPage() {
    return (
        <>
            <h2>404 NOT FOUND</h2>
            <p>Esta URL no está accesible o configurada.</p>
        </>
    )
}

export default ErrorPage;