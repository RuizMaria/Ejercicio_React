
function About() {
    return (
        <>
            <h2>SOBRE NOSOTROS</h2>
            <p>Esta es nuestra idea.</p>
        </>
    )
}

export default About;