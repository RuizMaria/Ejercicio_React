import './Footer.css';

function Footer() {
    return (
        <div className='header'>
            <p>Privacy and legal information</p>
        </div>
    )
}

export default Footer;