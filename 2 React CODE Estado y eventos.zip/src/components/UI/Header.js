import './Header.css';

function Header() {
    return (
        <div className='header'>
            <h2>LIST OR PRODUCTS</h2>
            <p>With description, date and price</p>
        </div>
    )
}

export default Header;