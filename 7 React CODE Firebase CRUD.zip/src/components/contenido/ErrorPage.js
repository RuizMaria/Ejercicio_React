
function ErrorPage() {
    return (
        <>
            <h2>404 NOT FOUND</h2>
            <p>Esta es nuestro error.</p>
        </>
    )
}

export default ErrorPage;